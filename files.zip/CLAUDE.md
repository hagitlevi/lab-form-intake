# lab-form-intake

Hackathon project (AI Open Code Hackathon 2026, Central Virology Lab challenge).
Turns scanned / photographed / handwritten lab commitment forms (טפסי התחייבות) into
structured records that a lab technician reviews, corrects and approves.
Final demo: 28/10/2026. Prefer simple, working code over abstractions.
If this file and the code disagree, this file wins: tell the user about the difference.

## Stack
- Backend: Python 3.13, FastAPI, psycopg 3 with ConnectionPool, PostgreSQL (Render, Frankfurt)
- Processing: PyMuPDF (PDF → images), OpenCV (preprocessing), Tesseract via pytesseract
  (lang "heb+eng", runs locally), zxing-cpp (barcodes), Anthropic SDK (multimodal extraction)
- Frontend: React + Vite, Hebrew RTL UI, built and served as static files by FastAPI (one service, one URL)
- Config from environment (.env locally, never committed): DATABASE_URL, ANTHROPIC_API_KEY,
  ANTHROPIC_MODEL, TESSERACT_CMD and TESSDATA_PREFIX (optional, Windows only),
  LOCAL_WORKERS (default 2), AI_WORKERS (default 6)
- Deployment: Render web service using Docker (needed for Tesseract + Hebrew data).
  Do NOT create a Dockerfile or deploy config until explicitly asked.
- Local environment: server on 127.0.0.1:8080 (use 127.0.0.1, not localhost, also in the Vite proxy);
  PostgreSQL in Docker container "labpg" on port 5433; run inside .venv with
  `python -m uvicorn backend.main:app --reload --reload-dir backend --port 8080`.

## Roles: who does what (do not mix these up)
- OCR (Tesseract) extracts ALL text on a page as words + bounding boxes. It does not decide which
  word is which field.
- The AI extracts the 7 fields from the page IMAGES (never from OCR text), so it reads
  handwriting, stamps and context independently.
- Plain code then (a) groups pages into forms using fixed printed patterns, and (b) checks every AI
  value against the OCR words / barcode. An exact match makes the field safe and gives its
  location (bbox); otherwise the field is flagged for review.

## Fields extracted per commitment (7)
first_name, last_name, national_id, central_numbers (list), received_date,
sender (hospital / HMO, chosen from a closed list), commitment_numbers (list).
One record per commitment number; patient fields live on the form and are shared.

## Domain rules
- Central number: lab sticker with a barcode and the word "מרכזי" beside it (often printed
  sideways). Sometimes handwritten, with no sticker and no barcode. Some forms have no central
  number at all: leave the field empty and flag it. A 6-digit barcode is not necessarily the
  central number (some are commitment numbers, e.g. Bnei Zion); only the "מרכזי" label or the AI
  decides. A form may have several central numbers: keep all.
- Handwritten central number may be followed by the received date, e.g. "947054-25.8": 6 digits =
  central number, "25.8" = received date (day.month). If the year is missing, infer it from the
  upload date and flag the field with the reason "year inferred".
- Received date: "התקבל" stamp, or handwritten under the central number.
- Commitment number: may appear as "מספר התחייבות", "דרישה", or (Leumit only) "דגימה".
  The word "דגימה" appears on most forms with other meanings; treat it as a commitment number
  only on Leumit forms. A form may have several commitment numbers: keep all. On hospital-system
  screen printouts with a table under "מספר התחייבות", every number in that column is a separate
  commitment.
- Sender: from the closed list backend/data/senders.json (HMOs: כללית, מכבי, מאוחדת, לאומית; Israeli
  hospitals; "תיירות מרפא" as a special value, pending confirmation from the lab).
- A field that cannot be read is left empty (null). Never guess a value.
- Formats differ a lot between senders (e.g. 4 digits on a sticker, 9 digits printed, handwritten,
  a leading letter like X132767). Validate commitment-number format per sender only when known.

## Pipeline
1. Split uploads into an ordered list of pages (file order as shown in the UI, then page order).
   Blank pages are dropped and reported to the user.
2. Per page, in parallel (LOCAL_WORKERS): digital-PDF check (text layer AND no full-page image);
   if scanned: preprocess (rotate, deskew, clean) → OCR words with bounding boxes → barcodes.
   If digital: take text from the PDF instead of preprocessing and OCR.
3. Group pages into forms (see Grouping).
4. Per form, in parallel (AI_WORKERS): ONE multimodal call with all page images of that form.
   The response may contain several forms if the group actually holds more than one form
   (different patients, or different central numbers with separate commitment numbers);
   such a split is flagged for review.
5. Validate and score each field (see Confidence).
6. Save as pending records; the technician reviews, corrects, approves.

## Grouping (step 3)
Default: EVERY page starts a new form. A page is attached to the previous page only with explicit
printed evidence. Checks in order, stop at first match:
   1. decoded 6-digit barcode (sticker candidate) → new form. It is NOT necessarily the central number;
   2. 6-digit number directly next to a printed "מרכזי" in OCR text (incl. OCR of crops around
      barcodes rotated 90°/270°; the label is often printed sideways) → new form;
   3. "Page/עמוד n of/מתוך m" with n > 1 → continuation of the previous page;
   4. otherwise → new form (default).
Continuations may cross file boundaries. A first page of the batch that says "page 2" has no previous
page: treat it as a new form and flag it.
NOT used for the decision: "מספר התחייבות" or any form title, patient-sticker presence, a different
national ID, case number ("מקרה"), form code in the margin, handwriting, the yellow highlighter or blue
handwritten IDs (the last three are artifacts of the sample files). Consecutive forms of the same
template share the form code and often the case number, so they must not merge.
Why: a wrong merge hides a form silently; a wrong split is visible and fixed with one click.
After AI extraction (step 4):
   - the AI sees two forms in one group (e.g. two central numbers) → split, flagged;
   - a form that comes back with no name, ID, central number and commitment number → flagged
     "probably a continuation of the previous form"; the UI offers "merge into previous form"
     (re-extracts the merged form with one AI call) and "this is a separate form".
"flagged" at form level marks an uncertain form boundary. It is different from the orange field
state in Confidence.
Note: all national IDs and names in the samples are identical (replaced), so "different ID" would
not work on the samples anyway.

## Confidence (per field, positive checks; any "no" → flagged for review)
AI found a value? → value passes the rules? → (central number only) barcode agrees?
→ exact same value found by another source (OCR words, or barcode for central numbers)? → SAFE.
Near match (one character different) is flagged and the differing character is reported.
Rules: Israeli ID check digit (pad to 9), date valid and not in the future,
sender in the closed list (fuzzy match), commitment number format per sender when known.
Only two states are shown in the UI: safe or "for review" (orange), always with a reason.
Too many flags is a failure just like too few: the challenge scenario is 30 forms with about 3
orange fields.

## Privacy
Only form page images are sent to the AI; OCR runs locally. Extract and store only the 7 fields,
their metadata and the page images. Never store full OCR text, diagnoses, addresses or phones.
Case numbers are not stored.

## Conventions
- Run the relevant tests after each change. Keep secrets out of code and git.
- Do not tune rules to a single page. Evaluate on all sample files and report wrong merges and wrong
  splits separately (wrong merges are the critical number).
- Do not write grouping_truth.json or the ground truth from the pipeline's own output.
- Finish each task with a short summary of what was built and how to run it, then stop.
